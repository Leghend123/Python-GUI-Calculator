from tkinter import *
def button_press(num):
    global equation_text
    equation_text= equation_text + str(num)

    equation_label.set(equation_text)

def equal():

    global equation_text
    try:
       total = str(eval(equation_text))
       equation_label.set(total)

       equation_text = total

    except ZeroDivisionError:
       equation_label.set("arithimetic error")

    except SyntaxError:

        equation_label.set("SyntaxError")



def clear():
    global equation_text
    equation_label.set("")
    equation_text= ""


window = Tk()
window.title("CALCULATOR PROGRAM")
window.geometry("500x500")

equation_text=""

equation_label = StringVar()

label =Label(window, textvariable=equation_label , font=('consolas',20),width=24,height=2, bg ='white' )
label.pack()

frame = Frame(window)
frame.pack()

button1 = Button(frame,text=1 ,font=35,command=lambda:button_press(1),
                 height =4, width=9, bg= 'lightblue',)
button1.grid(row=0, column=0)

button2 = Button(frame,text=2 ,font=35,command=lambda:button_press(2),
                 height =4, width=9, bg= 'lightblue',)
button2.grid(row=0, column=1)

button3 = Button(frame,text=3 ,font=35,command=lambda:button_press(3),
                 height =4, width=9, bg= 'lightblue',)
button3.grid(row=0, column=2)

button4 = Button(frame,text=4 ,font=35,command=lambda:button_press(4),
                 height =4, width=9, bg= 'lightblue',)
button4.grid(row=1, column=0)

button5 = Button(frame,text=5 ,font=35,command=lambda:button_press(6),
                 height =4, width=9, bg= 'lightblue',)
button5.grid(row=1, column=1)

button6 = Button(frame,text=6 ,font=35,command=lambda:button_press(6),
                 height =4, width=9, bg= 'lightblue',)
button6.grid(row=1, column=2)

button7 = Button(frame,text=7 ,font=35,command=lambda:button_press(7),
                 height =4, width=9, bg= 'lightblue',)
button7.grid(row=2, column=0)

button8 = Button(frame,text=8,font=35,command=lambda:button_press(8),
                 height =4, width=9, bg= 'lightblue',)
button8.grid(row=2, column=1)

button9 = Button(frame,text=9 ,font=35,command=lambda:button_press(9),
                 height =4, width=9, bg= 'lightblue',)
button9.grid(row=2, column=2)

button0 = Button(frame,text=0 ,font=35,command=lambda:button_press(0),
                 height =4, width=9, bg= 'lightblue',)
button0.grid(row=3, column=0)

button_equalto = Button(frame,text= "=" ,font=35,command=equal,
                 height =4, width=9, bg= 'lightblue',)
button_equalto.grid(row=3, column=2)

divide = Button(frame,text= "/" ,font=35,command=lambda:button_press("/"),
                 height =4, width=9, bg= 'lightblue',)
divide.grid(row=0, column=3)

Plus = Button(frame,text= "+" ,font=35,command=lambda:button_press("+"),
                 height =4, width=9, bg= 'lightblue',)
Plus.grid(row=1, column=3)

multiply = Button(frame,text= "*" ,font=35,command=lambda:button_press("*"),
                 height =4, width=9, bg= 'lightblue',)
multiply.grid(row=2, column=3)

subtract = Button(frame,text= "-" ,font=35,command=lambda:button_press("-"),
                 height =4, width=9, bg= 'lightblue',)
subtract.grid(row=3, column=3)

decimal = Button(frame,text= "." ,font=35,command=lambda:button_press("."),
                 height =4, width=9, bg= 'lightblue',)
decimal.grid(row=3, column=1)



clear= Button(frame,text= "clear" ,font=35,command= clear,
                 height =4, width=9, bg= 'lightblue',)
clear.grid(row=4, column=2)








window.mainloop()